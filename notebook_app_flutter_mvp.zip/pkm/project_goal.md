Imagine an app. 
The app has no login. 
The app is like a note taking app. 
You can switch between different notebooks.
You can create a notebook.
Every notebook has the following information: Title, Year, Subtitle.
Inside a notebook, there are notes. 
For every note, you can add : date, one image, one title, a caption. 
You can export all the notes into a printable pdf book