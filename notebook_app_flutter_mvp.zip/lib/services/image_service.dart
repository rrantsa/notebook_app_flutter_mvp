import 'dart:io';

class ImageService {

  static String getExecutableDirectory() {
    final exePath = Platform.resolvedExecutable;
    return File(exePath).parent.path;
  }

  static Future<Directory> getImagesDirectory() async {
    final exeDir = getExecutableDirectory();

    final imagesDir = Directory('$exeDir/images');

    if (!await imagesDir.exists()) {
      await imagesDir.create(recursive: true);
    }

    return imagesDir;
  }

  static Future<String> copyImage(File imageFile) async {

    final imagesDir = await getImagesDirectory();

    final fileName =
        DateTime.now().millisecondsSinceEpoch.toString() + ".jpg";

    final newPath = "${imagesDir.path}/$fileName";

    final newImage = await imageFile.copy(newPath);

    return newImage.path;
  }
}