
import 'package:flutter/material.dart';
import '../models/note.dart';

class CreateNoteScreen extends StatefulWidget {
  final int notebookId;

  const CreateNoteScreen({super.key, required this.notebookId});

  @override
  State<CreateNoteScreen> createState() => _CreateNoteScreenState();
}

class _CreateNoteScreenState extends State<CreateNoteScreen> {

  final titleController = TextEditingController();
  final captionController = TextEditingController();
  final dateController = TextEditingController();

  void save() {
    final note = Note(
      notebookId: widget.notebookId,
      title: titleController.text,
      caption: captionController.text,
      date: dateController.text,
    );

    Navigator.pop(context, note);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Create Note")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: titleController,
              decoration: const InputDecoration(labelText: "Title"),
            ),
            TextField(
              controller: dateController,
              decoration: const InputDecoration(labelText: "Date"),
            ),
            TextField(
              controller: captionController,
              decoration: const InputDecoration(labelText: "Caption"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: save,
              child: const Text("Save Note"),
            )
          ],
        ),
      ),
    );
  }
}
